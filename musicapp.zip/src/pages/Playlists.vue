<template>
    <div class="playlists">

    </div>
</template>

<script>
export default {
    name: 'Playlists',
    data() {
        return {
            
        }
    }
}
</script>
