module.exports = {
    google: {
        
    }
}